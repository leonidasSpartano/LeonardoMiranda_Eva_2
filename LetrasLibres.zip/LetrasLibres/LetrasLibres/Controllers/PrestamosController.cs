﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LetrasLibres.Model.Data;
using LetrasLibres.Model.Entity;

namespace LetrasLibres.Controllers
{
    /// Controlador para la gestión de préstamos de libros.
    [Route("api/[controller]")]
    [ApiController]
    public class PrestamosController : ControllerBase
    {
        private readonly AppDbContext _context;
        public PrestamosController(AppDbContext context)
        {
            _context = context;
        }
        /// Obtener todos los préstamos registrados.
        [HttpGet]
        public async Task<IActionResult> GetPrestamos()
        {
            var prestamos = await _context.Prestamos
                .Include(p => p.Libro)
                .Include(p => p.Usuario)
                .ToListAsync();

            if (!prestamos.Any())
                return NotFound(new { message = "❌ No hay préstamos registrados." });

            return Ok(new
            {
                message = $"✅ Se encontraron {prestamos.Count} préstamo(s).",
                prestamos
            });
        }
        /// Obtener un préstamo específico por ID.
        [HttpGet("{id}")]
        public async Task<IActionResult> GetPrestamo(int id)
        {
            if (id <= 0)
                return BadRequest(new { message = "❌ ID inválido." });

            var prestamo = await _context.Prestamos
                .Include(p => p.Libro)
                .Include(p => p.Usuario)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (prestamo == null)
                return NotFound(new { message = $"❌ No se encontró préstamo con ID {id}." });

            return Ok(prestamo);
        }

        /// Registrar un nuevo préstamo.
        [HttpPost]
        public async Task<IActionResult> RegistrarPrestamo([FromBody] Prestamo prestamo)
        {
            if (prestamo.LibroId <= 0 || prestamo.UsuarioId <= 0)
                return BadRequest(new { message = "❌ LibroId y UsuarioId deben ser mayores a cero." });

            var libro = await _context.Libros.FindAsync(prestamo.LibroId);
            if (libro == null)
                return NotFound(new { message = "❌ El libro especificado no existe." });

            var usuario = await _context.Usuarios.FindAsync(prestamo.UsuarioId);
            if (usuario == null)
                return NotFound(new { message = "❌ El usuario especificado no existe." });

            if (libro.EstaPrestado)
                return BadRequest(new { message = "❌ El libro ya se encuentra prestado." });

            libro.EstaPrestado = true;
            prestamo.FechaPrestamo = DateTime.Now;
            prestamo.FechaDevolucion = null;
            
            try
            {
                _context.Prestamos.Add(prestamo);
                await _context.SaveChangesAsync();

                return Ok(new { message = "✅ Préstamo registrado exitosamente.", prestamo });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "❌ Error al registrar el préstamo.", error = ex.Message });
            }
        }
        /// Registrar la devolución de un libro.
        /// Registrar la devolución de un libro mediante el ID del préstamo.
        /// <param name="request">Objeto con el ID del préstamo.</param>
        /// <returns>Mensaje de éxito o error.</returns>
        [HttpPost("/api/devoluciones")]
        public async Task<IActionResult> RegistrarDevolucion([FromBody] PrestamoRequest request)
        {
            if (request == null || request.PrestamoId <= 0)
                return BadRequest(new { message = "❌ El ID del préstamo debe ser mayor a cero." });

            var prestamo = await _context.Prestamos
                .Include(p => p.Libro)
                .FirstOrDefaultAsync(p => p.Id == request.PrestamoId);

            if (prestamo == null)
                return NotFound(new { message = $"❌ No se encontró el préstamo con ID {request.PrestamoId}." });

            if (prestamo.FechaDevolucion != null)
                return BadRequest(new { message = "❌ Este préstamo ya fue devuelto." });

            prestamo.FechaDevolucion = DateTime.Now;
            prestamo.Libro.EstaPrestado = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(new { message = "✅ Devolución registrada correctamente.", devolucion = prestamo });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "❌ Error al registrar la devolución.", error = ex.Message });
            }
        }

        /// Objeto para recibir el ID del préstamo a devolver.
        public class PrestamoRequest
        {
            public int PrestamoId { get; set; }
        }

        /// Eliminar un préstamo (solo si ya fue devuelto).
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarPrestamo(int id)
        {
            if (id <= 0)
                return BadRequest(new { message = "❌ El ID del préstamo debe ser mayor a cero." });

            var prestamo = await _context.Prestamos
                .Include(p => p.Libro)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (prestamo == null)
                return NotFound(new { message = $"❌ No se encontró ningún préstamo con ID {id}." });

            if (prestamo.FechaDevolucion == null)
                return BadRequest(new { message = "❌ No se puede eliminar un préstamo activo (sin devolución)." });

            try
            {
                _context.Prestamos.Remove(prestamo);
                await _context.SaveChangesAsync();

                return Ok(new { message = "✅ Préstamo eliminado correctamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "❌ Error al eliminar el préstamo.", error = ex.Message });
            }
        }
        /// Obtener todos los préstamos de un usuario específico.
        [HttpGet("usuario/{usuarioId}")]
        public async Task<IActionResult> ObtenerPrestamosPorUsuario(int usuarioId)
        {
            if (usuarioId <= 0)
                return BadRequest(new { message = "❌ El ID del usuario debe ser mayor a cero." });

            var usuarioExiste = await _context.Usuarios.AnyAsync(u => u.Id == usuarioId);
            if (!usuarioExiste)
                return NotFound(new { message = $"❌ No se encontró usuario con ID {usuarioId}." });

            var prestamos = await _context.Prestamos
                .Include(p => p.Libro)
                .Where(p => p.UsuarioId == usuarioId)
                .ToListAsync();

            if (!prestamos.Any())
                return NotFound(new { message = $"❌ El usuario con ID {usuarioId} no tiene préstamos registrados." });

            return Ok(new
            {
                message = $"✅ Se encontraron {prestamos.Count} préstamo(s) para el usuario con ID {usuarioId}.",
                prestamos
            });
        }
    }
}
