﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LetrasLibres.Model.Data;
using LetrasLibres.Model.Entity;
using System.ComponentModel.DataAnnotations;

namespace LetrasLibres.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly AppDbContext _context;
        public UsuariosController(AppDbContext context)
        {
            _context = context;
        }
        // GET: api/Usuarios
        [HttpGet]
        public async Task<IActionResult> GetUsuarios()
        {
            try
            {
                var usuarios = await _context.Usuarios.ToListAsync();

                if (usuarios == null || !usuarios.Any())
                    return NotFound(new { message = "❌ No hay usuarios registrados en el sistema." });

                return Ok(new
                {
                    message = $"✅ Se encontraron {usuarios.Count} usuario(s) registrados.",
                    usuarios
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "❌ Error al obtener los usuarios.",
                    error = ex.Message
                });
            }
        }
        // GET: api/Usuarios/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetUsuario(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
                return NotFound(new { message = $"❌ No se encontró ningún usuario con el ID {id}." });

            return Ok(new
            {
                message = "✅ Usuario encontrado correctamente.",
                usuario
            });
        }
        // PUT: api/Usuarios/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUsuario(int id, Usuario usuario)
        {
            if (id != usuario.Id)
                return BadRequest(new { message = "❌ El ID de la URL no coincide con el del cuerpo de la solicitud." });

            // Validaciones
            if (string.IsNullOrWhiteSpace(usuario.Nombre) || usuario.Nombre.ToLower() == "string")
                return BadRequest(new { message = "❌ El campo 'Nombre' es obligatorio y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(usuario.Apellido) || usuario.Apellido.ToLower() == "string")
                return BadRequest(new { message = "❌ El campo 'Apellido' es obligatorio y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(usuario.Email) || usuario.Email.ToLower() is "user@example.com" or "string")
                return BadRequest(new { message = "❌ El campo 'Email' es obligatorio y no puede usar un valor de ejemplo." });

            if (!new EmailAddressAttribute().IsValid(usuario.Email))
                return BadRequest(new { message = "❌ El formato del email no es válido." });

            try
            {
                _context.Entry(usuario).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                return Ok(new { message = "✅ Usuario actualizado correctamente.", usuario });
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UsuarioExists(id))
                    return NotFound(new { message = $"❌ No se encontró el usuario con ID {id}." });

                return StatusCode(500, new { message = "❌ Error de concurrencia al actualizar el usuario." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "❌ Error inesperado al actualizar.", error = ex.Message });
            }
        }
        // POST: api/Usuarios
        [HttpPost]
        public async Task<IActionResult> PostUsuario(Usuario usuario)
        {
            // Validaciones
            if (string.IsNullOrWhiteSpace(usuario.Nombre) || usuario.Nombre.ToLower() == "string")
                return BadRequest(new { message = "❌ El nombre del usuario es obligatorio y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(usuario.Apellido) || usuario.Apellido.ToLower() == "string")
                return BadRequest(new { message = "❌ El apellido del usuario es obligatorio y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(usuario.Email) || usuario.Email.ToLower() == "string")
                return BadRequest(new { message = "❌ El email es obligatorio y no puede ser 'string'." });

            if (!new EmailAddressAttribute().IsValid(usuario.Email))
                return BadRequest(new { message = "❌ El formato del email no es válido." });

            if (await _context.Usuarios.AnyAsync(u => u.Email == usuario.Email))
                return BadRequest(new { message = "❌ Ya existe un usuario registrado con ese email." });

            usuario.FechaRegistro = DateTime.Now;

            try
            {
                _context.Usuarios.Add(usuario);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "✅ Usuario creado correctamente.",
                    usuario
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "❌ Error al crear el usuario.",
                    error = ex.Message
                });
            }
        }
        // DELETE: api/Usuarios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            try
            {
                var usuario = await _context.Usuarios
                    .Include(u => u.Prestamos)
                    .FirstOrDefaultAsync(u => u.Id == id);

                if (usuario == null)
                    return NotFound(new { message = $"❌ No se encontró ningún usuario con ID {id}." });

                if (usuario.Prestamos != null && usuario.Prestamos.Any())
                    return BadRequest(new { message = "❌ No se puede eliminar el usuario porque tiene préstamos asociados." });

                _context.Usuarios.Remove(usuario);
                await _context.SaveChangesAsync();

                return Ok(new { message = "✅ Usuario eliminado correctamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "❌ Error interno al intentar eliminar el usuario.",
                    error = ex.Message
                });
            }
        }
        // Método auxiliar
        private bool UsuarioExists(int id)
        {
            return _context.Usuarios.Any(e => e.Id == id);
        }
    }
}
