﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LetrasLibres.Model.Data;
using LetrasLibres.Model.Entity;

namespace LetrasLibres.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibrosController : ControllerBase
    {
        private readonly AppDbContext _context;
        public LibrosController(AppDbContext context)
        {
            _context = context;
        }
        // GET: api/Libros
        // Obtiene todos los libros registrados
        [HttpGet]
        public async Task<IActionResult> GetLibros()
        {
            var libros = await _context.Libros.ToListAsync();

            if (libros == null || !libros.Any())
                return NotFound(new { message = "❌ No hay libros registrados en la base de datos." });

            return Ok(new
            {
                message = $"✅ Se encontraron {libros.Count} libro(s) registrados.",
                libros
            });
        }
        // GET: api/Libros/5
        // Obtiene un libro por su ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetLibro(int id)
        {
            var libro = await _context.Libros.FindAsync(id);

            if (libro == null)
                return NotFound(new { message = $"❌ No se encontró un libro con el ID {id}." });

            return Ok(new
            {
                message = $"✅ Libro con ID {id} encontrado exitosamente.",
                libro
            });
        }
        // PUT: api/Libros/5
        // Actualiza los datos de un libro si no está prestado
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLibro(int id, Libro libro)
        {
            var libroExistente = await _context.Libros.FindAsync(id);
            if (libroExistente == null)
                return NotFound(new { message = $"❌ No se encontró un libro con ID {id}." });

            if (libroExistente.EstaPrestado)
                return BadRequest(new { message = "❌ No se puede editar un libro que actualmente está prestado." });

            // Solo se actualizan los campos editables
            libroExistente.Titulo = libro.Titulo;
            libroExistente.Autor = libro.Autor;
            libroExistente.Editorial = libro.Editorial;
            libroExistente.AnioPublicacion = libro.AnioPublicacion;
            libroExistente.Genero = libro.Genero;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(new { message = "✅ Libro actualizado correctamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"❌ Error al actualizar el libro: {ex.Message}" });
            }
        }

        // POST: api/Libros
        // Crea un nuevo libro con validaciones de campos
        [HttpPost]
        public async Task<IActionResult> PostLibro(Libro libro)
        {
            var anioActual = DateTime.Now.Year;

            // Validaciones del año de publicación
            if (libro.AnioPublicacion < 868)
                return BadRequest(new { message = "❌ El año de publicación no puede ser menor a 868." });

            if (libro.AnioPublicacion > anioActual)
                return BadRequest(new { message = $"❌ El año de publicación no puede ser mayor al año actual ({anioActual})." });

            // Validaciones de campos de texto
            if (string.IsNullOrWhiteSpace(libro.Titulo) || libro.Titulo.ToLower() == "string")
                return BadRequest(new { message = "❌ El título es obligatorio y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(libro.Autor) || libro.Autor.ToLower() == "string")
                return BadRequest(new { message = "❌ El autor es obligatorio y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(libro.Editorial) || libro.Editorial.ToLower() == "string")
                return BadRequest(new { message = "❌ La editorial es obligatoria y no puede ser 'string'." });

            if (string.IsNullOrWhiteSpace(libro.Genero) || libro.Genero.ToLower() == "string")
                return BadRequest(new { message = "❌ El género es obligatorio y no puede ser 'string'." });

            // Valores por defecto
            libro.Id = 0;
            libro.EstaPrestado = false;
            libro.Prestamos = null;

            try
            {
                _context.Libros.Add(libro);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "✅ Libro creado correctamente.",
                    libro
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    message = "❌ No se pudo crear el libro.",
                    error = ex.Message
                });
            }
        }
        // DELETE: api/Libros/5
        // Elimina un libro solo si no está prestado
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLibro(int id)
        {
            try
            {
                var libro = await _context.Libros.FindAsync(id);

                if (libro == null)
                    return NotFound(new { message = $"❌ No existe el libro con ID {id}." });

                if (libro.EstaPrestado)
                    return BadRequest(new { message = "⚠️ No se puede eliminar un libro que está actualmente prestado." });

                _context.Libros.Remove(libro);
                await _context.SaveChangesAsync();

                return Ok(new { message = "✅ Libro eliminado correctamente." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"❌ Error al eliminar el libro: {ex.Message}" });
            }
        }
    }
}
