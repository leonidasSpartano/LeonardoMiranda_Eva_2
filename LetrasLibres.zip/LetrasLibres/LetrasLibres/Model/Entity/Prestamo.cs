﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace LetrasLibres.Model.Entity
{
    public class Prestamo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        // Relaciones
        [ForeignKey("Libro")]
        public int LibroId { get; set; }
        [JsonIgnore]
        public Libro? Libro { get; set; }

        [ForeignKey("Usuario")]
        public int UsuarioId { get; set; }
        [JsonIgnore]
        public Usuario? Usuario { get; set; }

        // Datos del préstamo
        public DateTime FechaPrestamo { get; set; }
        public DateTime? FechaDevolucion { get; set; } = null; // null si aún no se devuelve
    }
}
