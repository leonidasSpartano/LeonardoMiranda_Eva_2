﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace LetrasLibres.Model.Entity
{
    public class Libro
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string Titulo { get; set; } = string.Empty;
        public string Autor { get; set; } = string.Empty;
        [Required]
        public string Editorial { get; set; } = string.Empty;
        public int AnioPublicacion { get; set; }
        [Required]
        public string Genero { get; set; } = string.Empty;

        [DefaultValue(false)]
        public bool EstaPrestado { get; set; } = false;

        [JsonIgnore] // Swagger dejará de mostrarlo como campo editable
        public List<Prestamo>? Prestamos { get; set; }
    }
}
