﻿using LetrasLibres.Model.Entity;
using Microsoft.EntityFrameworkCore;

namespace LetrasLibres.Model.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Libro> Libros { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Prestamo> Prestamos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Relaciones y reglas

            // Un préstamo (Prestamo) está asociado a un solo libro (Libro),
            // pero un libro puede tener múltiples préstamos a lo largo del tiempo.
            // Esto configura una relación uno-a-muchos entre Libro y Prestamo.
            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Libro)
                .WithMany(l => l.Prestamos)
                .HasForeignKey(p => p.LibroId);

            // Un préstamo (Prestamo) también está asociado a un solo usuario (Usuario),
            // mientras que un usuario puede tener múltiples préstamos registrados.
            // Esto establece una relación uno-a-muchos entre Usuario y Prestamo.
            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Usuario)
                .WithMany(u => u.Prestamos)
                .HasForeignKey(p => p.UsuarioId);
        }
    }
}
